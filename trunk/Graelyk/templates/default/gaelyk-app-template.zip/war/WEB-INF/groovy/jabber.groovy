
def s = "Received message from ${message.from} with body ${message.body}"

println s