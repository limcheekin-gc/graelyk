//Add any needed import statements here:

//Add a list of Obgaektifiable domain classes to register here:
//e.g.
//register MyFirstDomainClass
//register MySecondDomainClass
//register com.somewhere.SomeDomainClass